public class HelloWorld {
    public HelloWorld() {
    }

    public static void main(String[] var0) {
        System.out.println("Hello, World");
    }
}
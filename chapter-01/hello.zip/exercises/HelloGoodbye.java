
public class HelloGoodbye {
    public HelloGoodbye() {
    }

    public static void main(String[] var0) {
        System.out.println("Hello " + var0[0] + " and " + var0[1] + ".");
        System.out.println("Goodbye " + var0[1] + " and " + var0[0] + ".");
    }
}
